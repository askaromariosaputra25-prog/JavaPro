package com.javapro.app.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInClient;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.common.api.ApiException;
import com.javapro.app.MainActivity;
import com.javapro.app.R;
import com.javapro.app.utils.SessionManager;

import java.util.concurrent.Executor;

public class LoginActivity extends AppCompatActivity {

    private SessionManager sessionManager;
    private SignInClient oneTapClient;
    private BeginSignInRequest signInRequest;
    private LinearLayout btnGoogleSignIn;
    private ImageView ivFingerprint;
    private TextView tvBiometricHint;

    private final ActivityResultLauncher<IntentSenderRequest> signInLauncher =
        registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                try {
                    SignInCredential credential = oneTapClient.getSignInCredentialFromIntent(result.getData());
                    String email = credential.getId();
                    String name = credential.getDisplayName() != null ? credential.getDisplayName() : "User";
                    String photoUrl = credential.getProfilePictureUri() != null
                        ? credential.getProfilePictureUri().toString() : "";

                    sessionManager.saveUserInfo(email, name, photoUrl);
                    sessionManager.setLoggedIn(true);
                    sessionManager.resetFailedAttempts();

                    // Setelah Google login pertama, langsung coba enroll biometric
                    enrollBiometric();
                } catch (ApiException e) {
                    Toast.makeText(this, "Sign-in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sessionManager = new SessionManager(this);
        btnGoogleSignIn = findViewById(R.id.btn_google_sign_in);
        ivFingerprint = findViewById(R.id.iv_fingerprint);
        tvBiometricHint = findViewById(R.id.tv_biometric_hint);

        setupOneTapSignIn();

        if (sessionManager.isLoggedIn()) {
            if (sessionManager.isBiometricEnrolled()) {
                // Sudah punya akun + fingerprint → langsung fingerprint
                showFingerprintUI();
                showBiometricPrompt();
            } else {
                goToMain();
            }
        } else {
            // Belum punya akun → tampilkan tombol Google
            showGoogleSignInUI();
        }
    }

    private void showGoogleSignInUI() {
        btnGoogleSignIn.setVisibility(View.VISIBLE);
        ivFingerprint.setVisibility(View.GONE);
        tvBiometricHint.setVisibility(View.GONE);
        btnGoogleSignIn.setOnClickListener(v -> startGoogleSignIn());
    }

    private void showFingerprintUI() {
        btnGoogleSignIn.setVisibility(View.GONE);
        ivFingerprint.setVisibility(View.VISIBLE);
        tvBiometricHint.setVisibility(View.VISIBLE);
        ivFingerprint.setOnClickListener(v -> showBiometricPrompt());
    }

    private void setupOneTapSignIn() {
        oneTapClient = Identity.getSignInClient(this);
        signInRequest = BeginSignInRequest.builder()
            .setGoogleIdTokenRequestOptions(
                BeginSignInRequest.GoogleIdTokenRequestOptions.builder()
                    .setSupported(true)
                    .setServerClientId(getString(R.string.default_web_client_id))
                    .setFilterByAuthorizedAccounts(false)
                    .build())
            .setAutoSelectEnabled(true)
            .build();
    }

    private void startGoogleSignIn() {
        oneTapClient.beginSignIn(signInRequest)
            .addOnSuccessListener(this, result -> {
                try {
                    signInLauncher.launch(new IntentSenderRequest.Builder(
                        result.getPendingIntent().getIntentSender()).build());
                } catch (Exception e) {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            })
            .addOnFailureListener(this, e ->
                Toast.makeText(this, "Google Sign-In not available: " + e.getMessage(), Toast.LENGTH_LONG).show()
            );
    }

    private void enrollBiometric() {
        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuth = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);

        if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            sessionManager.setBiometricEnrolled(true);
            showBiometricPrompt();
        } else {
            goToMain();
        }
    }

    private void showBiometricPrompt() {
        Executor executor = ContextCompat.getMainExecutor(this);

        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    sessionManager.incrementFailedAttempts();
                    int attempts = sessionManager.getFailedAttempts();

                    if (attempts >= 3) {
                        sessionManager.resetFailedAttempts();
                        sessionManager.setBiometricEnrolled(false);
                        Toast.makeText(LoginActivity.this,
                            "Too many failed attempts. Please sign in with Google.", Toast.LENGTH_LONG).show();
                        showGoogleSignInUI();
                    } else {
                        Toast.makeText(LoginActivity.this,
                            "Authentication error: " + errString, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    sessionManager.resetFailedAttempts();
                    goToMain();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    sessionManager.incrementFailedAttempts();
                    int attempts = sessionManager.getFailedAttempts();
                    if (attempts >= 3) {
                        Toast.makeText(LoginActivity.this,
                            "Fingerprint failed 3x. Sign in with Google.", Toast.LENGTH_LONG).show();
                        showGoogleSignInUI();
                    }
                }
            });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_prompt_title))
            .setSubtitle(getString(R.string.biometric_prompt_subtitle))
            .setDescription(getString(R.string.biometric_prompt_desc))
            .setNegativeButtonText(getString(R.string.biometric_cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
