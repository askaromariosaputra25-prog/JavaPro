JavaPro (versi 1) - Home + GameBoost, via Shizuku.
Ganti nama app: app/src/main/AndroidManifest.xml (android:label).
Build otomatis lewat GitHub Actions (lihat panduan di chat).
