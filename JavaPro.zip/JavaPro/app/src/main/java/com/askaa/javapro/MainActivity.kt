package com.askaa.javapro

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

val cBG = Color(0xFF0A1412)
val cCard = Color(0xFF14201D)
val cAcc = Color(0xFF86D9D3)
val cDim = Color(0xFF8FA8A4)
val cPill = Color(0xFF22332F)

data class Game(val pkg: String, val name: String)

val known = setOf(
    "com.mobile.legends", "com.mobilelegends.hwag", "com.tencent.ig", "com.pubg.imobile",
    "com.dts.freefireth", "com.dts.freefiremax", "com.miHoYo.GenshinImpact",
    "com.activision.callofduty.shooter", "com.garena.game.codm", "com.roblox.client",
    "com.levelinfinite.sgameGlobal", "com.mojang.minecraftpe"
)

fun loadGames(pm: PackageManager): List<Game> =
    pm.getInstalledApplications(0)
        .filter { it.packageName in known || it.category == ApplicationInfo.CATEGORY_GAME }
        .map { Game(it.packageName, pm.getApplicationLabel(it).toString()) }
        .sortedBy { it.name }

object Sh {
    private val newProc by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    fun state(): Int = try {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    } catch (e: Throwable) { 0 }

    fun run(cmd: String): String = try {
        val p = newProc.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out
    } catch (e: Throwable) { "ERROR: " + (e.cause?.message ?: e.message) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0A1412.toInt()
        window.navigationBarColor = 0xFF0A1412.toInt()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = cAcc, onPrimary = Color(0xFF00201E), background = cBG,
                    surface = cCard, onSurface = Color(0xFFDDE8E6), onBackground = Color(0xFFDDE8E6),
                    secondaryContainer = Color(0xFF1F3A37)
                )
            ) { Root() }
        }
    }
}

@Composable
fun Root() {
    var tab by remember { mutableStateOf(0) }
    var game by remember { mutableStateOf<Game?>(null) }
    var st by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { st = withContext(Dispatchers.IO) { Sh.state() }; delay(2000) }
    }
    BackHandler(game != null) { game = null }
    Scaffold(containerColor = cBG, bottomBar = {
        if (game == null) NavigationBar(containerColor = cCard) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.Filled.PlayArrow, null) }, label = { Text("GameBoost") })
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val g = game
            if (g != null) GameScreen(g, st) { game = null }
            else if (tab == 0) Home(st)
            else Games(st) { game = it }
        }
    }
}

@Composable
fun H(t: String) = Text(t, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = cCard)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun Stat(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = cDim); Text(v, color = Color.White, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ShizukuBox(st: Int) {
    Panel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (st) {
                    2 -> "Shizuku: Connected"
                    1 -> "Shizuku: izin belum diberikan"
                    else -> "Shizuku: tidak aktif (buka app Shizuku lalu Start)"
                },
                color = if (st == 2) cAcc else Color(0xFFE6A5A5), modifier = Modifier.weight(1f)
            )
            if (st == 1) Button({ try { Shizuku.requestPermission(100) } catch (e: Throwable) {} }) { Text("Beri izin") }
        }
    }
}

@Composable
fun Home(st: Int) {
    val ctx = LocalContext.current
    var cpu by remember { mutableStateOf(-1) }
    var prev by remember { mutableStateOf<LongArray?>(null) }
    var ram by remember { mutableStateOf("-") }
    var bat by remember { mutableStateOf(0) }
    LaunchedEffect(st) {
        while (true) {
            val mi = ActivityManager.MemoryInfo()
            ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            ram = "%.1f / %.1f GB".format((mi.totalMem - mi.availMem) / 1e9, mi.totalMem / 1e9)
            bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let {
                it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / maxOf(1, it.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
            } ?: 0
            if (st == 2) {
                val line = withContext(Dispatchers.IO) { Sh.run("head -1 /proc/stat") }
                val n = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (n.size >= 5) {
                    val tot = n.sum(); val idle = n[3] + n[4]
                    prev?.let { p ->
                        val dt = tot - p[0]; val di = idle - p[1]
                        if (dt > 0) cpu = (100 * (dt - di) / dt).toInt()
                    }
                    prev = longArrayOf(tot, idle)
                }
            }
            delay(2000)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        H("JavaPro"); Spacer(Modifier.height(8.dp))
        ShizukuBox(st)
        Panel {
            Text("System Health", color = cAcc, fontWeight = FontWeight.Bold)
            Stat("Device", Build.MODEL); Stat("Android", Build.VERSION.RELEASE)
            Stat("CPU", if (cpu >= 0) "$cpu%" else "-"); Stat("RAM", ram); Stat("Baterai", "$bat%")
        }
    }
}

@Composable
fun Games(st: Int, onPick: (Game) -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf<List<Game>?>(null) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { list = withContext(Dispatchers.IO) { loadGames(ctx.packageManager) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        H("GameBoost"); Spacer(Modifier.height(8.dp))
        ShizukuBox(st)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari game...") }, singleLine = true)
        val l = list
        if (l == null) CircularProgressIndicator()
        else if (l.isEmpty()) Text("Belum ada game terdeteksi", color = cDim, modifier = Modifier.padding(16.dp))
        else LazyColumn {
            items(l.filter { it.name.contains(q, true) }) { g ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onPick(g) },
                    colors = CardDefaults.cardColors(containerColor = cCard)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(g.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(g.pkg, color = cDim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun Pill(t: String, sel: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) cAcc else cPill)
        .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(t, color = if (sel) Color(0xFF00201E) else Color.White)
    }
}

@Composable
fun Opt(t: String, d: String, k: String, o: MutableMap<String, Boolean>) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(t, color = Color.White); Text(d, color = cDim, fontSize = 12.sp) }
        Switch(checked = o[k] == true, onCheckedChange = { o[k] = it })
    }
}

@Composable
fun GameScreen(g: Game, st: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val opts = remember {
        mutableStateMapOf("ram" to true, "prio" to true, "anim" to true, "touch" to true, "mode" to true, "mem" to true)
    }
    var pct by remember { mutableStateOf(100) }
    var fps by remember { mutableStateOf(0) }
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val p = g.pkg

    fun exec(title: String, cmds: List<String>) {
        if (st != 2) { log = "Shizuku belum aktif / belum diberi izin."; return }
        busy = true
        scope.launch {
            val sb = StringBuilder("$title\n")
            for (c in cmds) {
                val o = withContext(Dispatchers.IO) { Sh.run(c) }
                sb.append("> ").append(c.take(50)).append("\n")
                if (o.isNotBlank()) sb.append(o.take(200)).append("\n")
                log = sb.toString()
            }
            log = sb.append("Selesai.").toString()
            busy = false
        }
    }

    fun boost(): List<String> {
        val l = mutableListOf<String>()
        if (opts["ram"] == true) l += "am kill-all"
        if (opts["prio"] == true) { l += "am set-standby-bucket $p active"; l += "cmd deviceidle whitelist +$p" }
        if (opts["anim"] == true) l += "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5"
        if (opts["touch"] == true) l += "settings put secure long_press_timeout 250"
        if (opts["mode"] == true) l += "cmd game mode performance $p"
        if (opts["mem"] == true) l += "for x in \$(pm list packages -3 | cut -d: -f2); do [ \"\$x\" != \"$p\" ] && am send-trim-memory --user 0 \$x COMPLETE; done; sync"
        return l
    }

    val resCmd = if (pct >= 100) "wm size reset" else
        "s=\$(wm size | grep -oE '[0-9]+x[0-9]+' | head -1); w=\$(echo \$s | cut -dx -f1); h=\$(echo \$s | cut -dx -f2); wm size \$((w*$pct/100))x\$((h*$pct/100))"
    val fpsCmd = if (fps == 0) "settings delete system peak_refresh_rate; settings delete system min_refresh_rate; settings delete system user_refresh_rate"
    else "settings put system peak_refresh_rate $fps; settings put system min_refresh_rate $fps; settings put system user_refresh_rate $fps"
    val resetCmd = "settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0; settings put secure long_press_timeout 400; wm size reset; settings delete system peak_refresh_rate; settings delete system min_refresh_rate; settings delete system user_refresh_rate; cmd game mode standard $p"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
            H(g.name)
        }
        Text(p, color = cDim, fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ exec("Boost", boost()) }, Modifier.weight(1f), enabled = !busy) { Text("Boost!") }
            Button({ ctx.packageManager.getLaunchIntentForPackage(p)?.let { ctx.startActivity(it) } }, Modifier.weight(1f)) { Text("Play!") }
            Button({ exec("Stop", listOf("am force-stop $p")) }, Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8C4A52))) { Text("Stop") }
        }
        Panel {
            Text("Boost Options", color = cAcc, fontWeight = FontWeight.Bold)
            Opt("Clear Background RAM", "Tutup proses background", "ram", opts)
            Opt("Prioritize Game", "Bucket aktif + whitelist baterai", "prio", opts)
            Opt("Reduce Animations", "Animasi sistem jadi 0.5x", "anim", opts)
            Opt("Touch Boost", "Kurangi delay sentuhan", "touch", opts)
            Opt("Android Game Mode", "Mode Performance bawaan Android", "mode", opts)
            Opt("Memory Optimization", "Minta app lain lepas memori", "mem", opts)
        }
        Panel {
            Text("Resolution Scale", color = cAcc, fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(50, 60, 70, 80, 90, 100).forEach { Pill(if (it == 100) "Off" else "${it / 100f}x", pct == it) { pct = it } }
            }
            Text("FPS Target", color = cAcc, fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 30, 60, 90).forEach { Pill(if (it == 0) "Off" else "$it", fps == it) { fps = it } }
            }
            Text("Hasil FPS & resolusi tergantung ROM. Kalau layar aneh, tekan Reset Semua.", color = cDim, fontSize = 12.sp)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ exec("Apply grafik", listOf(resCmd, fpsCmd)) }, Modifier.weight(1f), enabled = !busy) { Text("Apply") }
                OutlinedButton({ exec("Reset semua", listOf(resetCmd)) }, Modifier.weight(1f), enabled = !busy) { Text("Reset Semua") }
            }
        }
        if (busy || log.isNotEmpty()) Panel {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(log, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = cDim)
        }
    }
}
