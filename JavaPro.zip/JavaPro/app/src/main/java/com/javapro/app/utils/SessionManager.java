package com.javapro.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    
    private static final String PREF_NAME = "javapro_session";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_PHOTO = "user_photo";
    private static final String KEY_BIOMETRIC_ENROLLED = "biometric_enrolled";
    private static final String KEY_FAILED_ATTEMPTS = "failed_attempts";
    
    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;
    
    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }
    
    public void setLoggedIn(boolean status) {
        editor.putBoolean(KEY_IS_LOGGED_IN, status);
        editor.apply();
    }
    
    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }
    
    public void saveUserInfo(String email, String name, String photoUrl) {
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_PHOTO, photoUrl);
        editor.apply();
    }
    
    public String getUserEmail() { return prefs.getString(KEY_USER_EMAIL, ""); }
    public String getUserName() { return prefs.getString(KEY_USER_NAME, ""); }
    public String getUserPhoto() { return prefs.getString(KEY_USER_PHOTO, ""); }
    
    public void setBiometricEnrolled(boolean enrolled) {
        editor.putBoolean(KEY_BIOMETRIC_ENROLLED, enrolled);
        editor.apply();
    }
    
    public boolean isBiometricEnrolled() {
        return prefs.getBoolean(KEY_BIOMETRIC_ENROLLED, false);
    }
    
    public void incrementFailedAttempts() {
        int current = prefs.getInt(KEY_FAILED_ATTEMPTS, 0);
        editor.putInt(KEY_FAILED_ATTEMPTS, current + 1);
        editor.apply();
    }
    
    public int getFailedAttempts() {
        return prefs.getInt(KEY_FAILED_ATTEMPTS, 0);
    }
    
    public void resetFailedAttempts() {
        editor.putInt(KEY_FAILED_ATTEMPTS, 0);
        editor.apply();
    }
    
    public void logout() {
        editor.clear();
        editor.apply();
    }
}
