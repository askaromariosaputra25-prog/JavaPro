package com.javapro.app.ui.advanced;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.javapro.app.R;
import com.javapro.app.shizuku.ShizukuHelper;
import com.javapro.app.utils.SystemStatsHelper;

public class AdvancedFragment extends Fragment {

    private SwitchMaterial switchApplyBoot;
    private TextView tvBattery, tvMemory;
    private TextView tvSwappiness, tvCachePressure, tvDirtyRatio, tvPageCluster;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_advanced, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvBattery = view.findViewById(R.id.tv_battery);
        tvMemory = view.findViewById(R.id.tv_memory);
        tvSwappiness = view.findViewById(R.id.tv_swappiness);
        tvCachePressure = view.findViewById(R.id.tv_cache_pressure);
        tvDirtyRatio = view.findViewById(R.id.tv_dirty_ratio);
        tvPageCluster = view.findViewById(R.id.tv_page_cluster);
        switchApplyBoot = view.findViewById(R.id.switch_apply_boot);

        setupSeekBars(view);
        loadStats();

        switchApplyBoot.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) {
                Toast.makeText(getContext(), "Apply on Boot enabled", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSeekBars(View view) {
        SeekBar seekSwappiness = view.findViewById(R.id.seek_swappiness);
        seekSwappiness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvSwappiness.setText(String.valueOf(progress));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                applyVmSetting("vm.swappiness", s.getProgress());
            }
        });

        SeekBar seekCachePressure = view.findViewById(R.id.seek_cache_pressure);
        seekCachePressure.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvCachePressure.setText(String.valueOf(progress));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                applyVmSetting("vm.vfs_cache_pressure", s.getProgress());
            }
        });

        SeekBar seekDirtyRatio = view.findViewById(R.id.seek_dirty_ratio);
        seekDirtyRatio.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvDirtyRatio.setText(String.valueOf(progress));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                applyVmSetting("vm.dirty_ratio", s.getProgress());
            }
        });

        SeekBar seekPageCluster = view.findViewById(R.id.seek_page_cluster);
        seekPageCluster.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvPageCluster.setText(String.valueOf(progress));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {
                applyVmSetting("vm.page-cluster", s.getProgress());
            }
        });
    }

    private void applyVmSetting(String key, int value) {
        if (ShizukuHelper.hasShizukuPermission()) {
            String result = ShizukuHelper.runKernelTweak("/proc/sys/" + key.replace(".", "/"), String.valueOf(value));
            Toast.makeText(getContext(), key + " = " + value, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "Shizuku needed for " + key, Toast.LENGTH_SHORT).show();
        }
    }

    private void loadStats() {
        if (getContext() == null) return;
        SystemStatsHelper stats = new SystemStatsHelper(getContext());
        tvMemory.setText(stats.getAvailableRamGb());
        tvBattery.setText("34%");
    }
}
