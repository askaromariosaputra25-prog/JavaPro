package com.javapro.app.ui.home;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.javapro.app.R;
import com.javapro.app.shizuku.ShizukuHelper;
import com.javapro.app.utils.SystemStatsHelper;

public class HomeFragment extends Fragment {

    private TextView tvCpuUsage, tvRamUsage, tvTemp, tvLittleCore, tvBigCore;
    private Handler refreshHandler;
    private Runnable refreshRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvCpuUsage = view.findViewById(R.id.tv_cpu_usage);
        tvRamUsage = view.findViewById(R.id.tv_ram_usage);
        tvTemp = view.findViewById(R.id.tv_temp);
        tvLittleCore = view.findViewById(R.id.tv_little_core);
        tvBigCore = view.findViewById(R.id.tv_big_core);

        // Quick menu clicks
        view.findViewById(R.id.menu_app_profiles).setOnClickListener(v ->
            Toast.makeText(getContext(), "App Profiles", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.menu_system_monitor).setOnClickListener(v ->
            Toast.makeText(getContext(), "System Monitor", Toast.LENGTH_SHORT).show());

        // Tools clicks
        view.findViewById(R.id.tool_app_analyzer).setOnClickListener(v ->
            Toast.makeText(getContext(), "App Analyzer", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.tool_network_monitor).setOnClickListener(v ->
            Toast.makeText(getContext(), "Network Monitor", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.tool_storage_cleaner).setOnClickListener(v ->
            Toast.makeText(getContext(), "Storage Cleaner", Toast.LENGTH_SHORT).show());
        view.findViewById(R.id.tool_wakelock).setOnClickListener(v ->
            Toast.makeText(getContext(), "Wakelock Analyzer", Toast.LENGTH_SHORT).show());

        // Support clicks
        setupSupportClicks(view);

        // Start live stats refresh
        startStatsRefresh();
    }

    private void setupSupportClicks(View view) {
        view.findViewById(R.id.support_donate).setOnClickListener(v ->
            openUrl("https://saweria.co/javapro"));
        view.findViewById(R.id.support_whatsapp).setOnClickListener(v ->
            openUrl("https://wa.me/"));
        view.findViewById(R.id.support_telegram).setOnClickListener(v ->
            openUrl("https://t.me/javapro"));
        view.findViewById(R.id.support_report).setOnClickListener(v ->
            openUrl("https://github.com/javapro/report/issues"));
    }

    private void openUrl(String url) {
        try {
            android.content.Intent intent = new android.content.Intent(
                android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(getContext(), "Cannot open link", Toast.LENGTH_SHORT).show();
        }
    }

    private void startStatsRefresh() {
        refreshHandler = new Handler(Looper.getMainLooper());
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                updateStats();
                refreshHandler.postDelayed(this, 2000);
            }
        };
        refreshHandler.post(refreshRunnable);
    }

    private void updateStats() {
        if (getContext() == null) return;
        
        SystemStatsHelper stats = new SystemStatsHelper(getContext());
        
        String cpu = stats.getCpuUsage() + "%";
        String ram = stats.getAvailableRamGb();
        String temp = stats.getCpuTemp() + "°C";
        String little = stats.getLittleCoreFreq() + " MHz";
        String big = stats.getBigCoreFreq() + " MHz";
        
        tvCpuUsage.setText(cpu);
        tvRamUsage.setText(ram);
        tvTemp.setText(temp);
        tvLittleCore.setText(little);
        tvBigCore.setText(big);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (refreshHandler != null && refreshRunnable != null) {
            refreshHandler.removeCallbacks(refreshRunnable);
        }
    }
}
