package com.nexuspro.app

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager

class CrosshairService : Service() {
    private var view: CrosshairView? = null
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP" || !Settings.canDrawOverlays(this)) {
            removeView(); stopSelf(); return START_NOT_STICKY
        }
        if (view == null) {
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT)
            view = CrosshairView(this).also { wm.addView(it, lp) }
        }
        view?.load(U.prefs(this, "crosshair"))
        return START_STICKY
    }

    private fun removeView() { view?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; view = null }
    override fun onDestroy() { removeView(); super.onDestroy() }
}
