package com.nexuspro.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class CrosshairView(c: Context, a: AttributeSet? = null) : View(c, a) {
    var model = 0          // 0 Classic Cross, 1 Dot Only, 2 Circle + Dot
    var color = Color.RED
    var size = 40
    var thick = 3
    var opacity = 100
    var offX = 0
    var offY = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun load(s: SharedPreferences) {
        model = s.getInt("model", 0); color = s.getInt("color", Color.RED)
        size = s.getInt("size", 40); thick = s.getInt("thick", 3)
        opacity = s.getInt("opacity", 100); offX = s.getInt("x", 0); offY = s.getInt("y", 0)
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f + offX * d
        val cy = height / 2f + offY * d
        val half = size / 2f * d
        p.color = color
        p.alpha = opacity * 255 / 100
        p.strokeWidth = thick * d
        when (model) {
            0 -> {
                p.style = Paint.Style.STROKE
                cv.drawLine(cx - half, cy, cx + half, cy, p)
                cv.drawLine(cx, cy - half, cx, cy + half, p)
            }
            1 -> { p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, thick * d * 1.5f, p) }
            else -> {
                p.style = Paint.Style.STROKE
                cv.drawCircle(cx, cy, half, p)
                p.style = Paint.Style.FILL
                cv.drawCircle(cx, cy, thick * d * 1.2f, p)
            }
        }
    }
}
