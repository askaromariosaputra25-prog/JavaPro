package com.nexuspro.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        ShizukuHelper.request(100)
        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener {
            show(when (it.itemId) {
                R.id.nav_game -> GameBoostFragment()
                R.id.nav_advanced -> AdvancedFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }); true
        }
        if (savedInstanceState == null) nav.selectedItemId = R.id.nav_home
    }

    private fun show(f: Fragment) =
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
}
