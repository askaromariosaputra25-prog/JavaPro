package com.nexuspro.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {
    private val h = Handler(Looper.getMainLooper())
    private var shizukuTag: TextView? = null
    private lateinit var v: View
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 2000) }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_home, c, false).also { v = it }

    override fun onViewCreated(view: View, s: Bundle?) {
        val ctx = requireContext()
        fun open(cls: Class<*>) = { startActivity(Intent(ctx, cls)) }
        fun soon() = { Toast.makeText(ctx, "Coming soon", Toast.LENGTH_SHORT).show() }
        // Ganti URL berikut dengan link milikmu
        fun url(u: String) = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }

        v.findViewById<LinearLayout>(R.id.llMenu).apply {
            addRow("App Profiles", "Profil performa per aplikasi", onClick = open(AppListActivity::class.java))
            addRow("System Monitor", "CPU, GPU, RAM, Storage", onClick = open(SystemMonitorActivity::class.java))
        }
        shizukuTag = v.findViewById<LinearLayout>(R.id.llConn)
            .addRow("Shizuku", "Status koneksi", "Inactive") { ShizukuHelper.request(100) }
            .findViewById(R.id.txtTag)
        v.findViewById<LinearLayout>(R.id.llExclusive).addRow("Exclusive Features", "Semua fitur terbuka", "FREE")
        v.findViewById<LinearLayout>(R.id.llTools).apply {
            addRow("App Analyzer", onClick = open(AppListActivity::class.java))
            addRow("Network Monitor", onClick = open(PingTestActivity::class.java))
            addRow("Storage Cleaner", onClick = soon())
            addRow("Wakelock Analyzer", onClick = soon())
        }
        v.findViewById<LinearLayout>(R.id.llSupport).apply {
            addRow("Donate", onClick = url("https://saweria.co/"))
            addRow("WhatsApp", onClick = url("https://wa.me/"))
            addRow("Report Bug", onClick = url("https://github.com/"))
            addRow("Telegram", onClick = url("https://t.me/"))
            addRow("Credits", onClick = soon())
        }
    }

    private fun update() {
        val ctx = context ?: return
        val cores = SysInfo.cpuCores()
        val load = SysInfo.cpuLoad(cores)
        v.findViewById<TextView>(R.id.txtCpu).text = "CPU $load%"
        if (cores.isNotEmpty()) {
            val little = cores.first(); val big = cores.last()
            v.findViewById<TextView>(R.id.txtLittle).text = "Little Core  ${little.first}MHz"
            v.findViewById<TextView>(R.id.txtBig).text = "Big Core  ${big.first}MHz"
            v.findViewById<ProgressBar>(R.id.pbLittle).progress = pct(little.first, little.second)
            v.findViewById<ProgressBar>(R.id.pbBig).progress = pct(big.first, big.second)
        }
        val (used, total) = SysInfo.ram(ctx)
        v.findViewById<TextView>(R.id.txtStat1).text = "CPU ${U.prefs(ctx, "bench").getInt("single", 2987)}"
        v.findViewById<TextView>(R.id.txtStat2).text = "${cores.size} Cores"
        v.findViewById<TextView>(R.id.txtStat3).text = "${U.fmt(total)}  ${used * 100 / total}%"
        val on = ShizukuHelper.isAvailable() && ShizukuHelper.hasPermission()
        shizukuTag?.text = if (on) "Active" else "Inactive"
        v.findViewById<TextView>(R.id.txtStatus).apply {
            text = "● Alive"
        }
    }

    private fun pct(cur: Long, max: Long) = if (max == 0L) 0 else (cur * 100 / max).toInt()

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
