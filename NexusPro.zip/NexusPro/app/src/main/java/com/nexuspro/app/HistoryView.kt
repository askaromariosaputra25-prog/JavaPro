package com.nexuspro.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

class HistoryView(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val cpu = ArrayDeque<Float>()
    private val ram = ArrayDeque<Float>()
    private val grid = Paint().apply { color = Color.parseColor("#2C2C2E"); strokeWidth = 2f }
    private val pCpu = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0A84FF"); style = Paint.Style.STROKE; strokeWidth = 4f }
    private val pRam = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#30D158"); style = Paint.Style.STROKE; strokeWidth = 4f }

    fun add(c: Float, r: Float) {
        cpu.addLast(c); ram.addLast(r)
        while (cpu.size > 720) { cpu.removeFirst(); ram.removeFirst() } // 720 x 5s = 1 jam
        invalidate()
    }

    private fun draw(cv: Canvas, d: ArrayDeque<Float>, p: Paint) {
        if (d.size < 2) return
        val path = Path()
        val step = width / 719f
        d.forEachIndexed { i, v ->
            val x = i * step
            val y = height - (v.coerceIn(0f, 100f) / 100f) * height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        cv.drawPath(path, p)
    }

    override fun onDraw(cv: Canvas) {
        for (i in 0..4) cv.drawLine(0f, height * i / 4f, width.toFloat(), height * i / 4f, grid)
        draw(cv, cpu, pCpu); draw(cv, ram, pRam)
    }
}
