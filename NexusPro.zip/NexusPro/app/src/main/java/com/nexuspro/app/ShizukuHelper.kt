package com.nexuspro.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.File

object ShizukuHelper {
    fun isAvailable(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request(code: Int) {
        try { if (isAvailable() && !hasPermission()) Shizuku.requestPermission(code) } catch (_: Throwable) {}
    }

    /** Jalankan perintah shell lewat Shizuku (newProcess bersifat private di API 13 -> reflection). */
    fun exec(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) { "ERR: ${e.message}" }
}

object Shell {
    fun hasRoot(): Boolean = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sbin/su")
        .any { File(it).exists() }

    fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor(); out.trim()
    } catch (e: Throwable) { "ERR: ${e.message}" }

    /** Prioritas: root, lalu Shizuku. */
    fun run(cmd: String): String = when {
        hasRoot() -> su(cmd)
        ShizukuHelper.isAvailable() && ShizukuHelper.hasPermission() -> ShizukuHelper.exec(cmd)
        else -> "ERR: butuh root atau Shizuku aktif"
    }
}
