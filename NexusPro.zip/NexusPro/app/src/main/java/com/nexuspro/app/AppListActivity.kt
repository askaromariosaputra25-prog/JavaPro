package com.nexuspro.app

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AppListActivity : BaseActivity() {
    private val all = mutableListOf<Pair<String, String>>()
    private val shown = mutableListOf<Pair<String, String>>()
    private lateinit var adapter: Adapter
    private lateinit var txtCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)
        setupHeader("App Profiles")
        txtCount = findViewById(R.id.txtCount)
        val progress = findViewById<ProgressBar>(R.id.progress)
        val rv = findViewById<RecyclerView>(R.id.recycler)
        adapter = Adapter(); rv.layoutManager = LinearLayoutManager(this); rv.adapter = adapter

        Thread {
            Thread.sleep(600)
            val pm = packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
                .map { pm.getApplicationLabel(it).toString() to it.packageName }
                .sortedBy { it.first.lowercase() }
            runOnUiThread {
                all.addAll(apps); filter(""); progress.visibility = View.GONE
            }
        }.start()

        findViewById<EditText>(R.id.edtSearch).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = filter(e.toString())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun filter(q: String) {
        shown.clear()
        shown.addAll(all.filter { it.first.contains(q, true) || it.second.contains(q, true) })
        txtCount.text = "${shown.size} apps"
        adapter.notifyDataSetChanged()
    }

    inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        inner class VH(val v: View) : RecyclerView.ViewHolder(v)
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val v = LayoutInflater.from(p.context).inflate(R.layout.item_row, p, false)
            v.setBackgroundResource(R.drawable.bg_card)
            val pad = U.dp(p.context, 16)
            v.setPadding(pad, pad, pad, pad)
            v.layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) }
            return VH(v)
        }
        override fun getItemCount() = shown.size
        override fun onBindViewHolder(h: VH, i: Int) {
            h.v.findViewById<TextView>(R.id.txtTitle).text = shown[i].first
            h.v.findViewById<TextView>(R.id.txtSub).text = shown[i].second
            h.v.findViewById<TextView>(R.id.txtTag).text = "BALANCED"
        }
    }
}
