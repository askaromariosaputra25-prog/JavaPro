package com.nexuspro.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.material.materialswitch.MaterialSwitch

class CrosshairActivity : BaseActivity() {
    private val prefs by lazy { U.prefs(this, "crosshair") }
    private lateinit var preview: CrosshairView
    private lateinit var sw: MaterialSwitch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crosshair)
        setupHeader("Custom Crosshair")
        preview = findViewById(R.id.preview); preview.load(prefs)
        sw = findViewById(R.id.swEnable)
        sw.isChecked = prefs.getBoolean("enabled", false) && Settings.canDrawOverlays(this)
        sw.setOnCheckedChangeListener { _, on ->
            if (on && !Settings.canDrawOverlays(this)) {
                sw.isChecked = false
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else { prefs.edit().putBoolean("enabled", on).apply(); pushService() }
        }
        val rg = findViewById<RadioGroup>(R.id.rgModel)
        rg.check(listOf(R.id.rbClassic, R.id.rbDot, R.id.rbCircle)[prefs.getInt("model", 0)])
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("model", when (id) { R.id.rbDot -> 1; R.id.rbCircle -> 2; else -> 0 }).apply(); refresh()
        }
        val colors = findViewById<LinearLayout>(R.id.llColors)
        listOf("#FF453A", "#30D158", "#0A84FF", "#FFD60A", "#FFFFFF", "#64D2FF").forEach { hex ->
            colors.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(U.dp(context, 36), U.dp(context, 36)).apply { setMargins(0, 8, 14, 8) }
                setBackgroundColor(Color.parseColor(hex))
                setOnClickListener { prefs.edit().putInt("color", Color.parseColor(hex)).apply(); refresh() }
            })
        }
        val ll = findViewById<LinearLayout>(R.id.llSliders)
        slider(ll, "Size", "size", 10, 120, 40, "")
        slider(ll, "Thickness", "thick", 1, 12, 3, "")
        slider(ll, "Opacity", "opacity", 10, 100, 100, "%")
        slider(ll, "Position X", "x", -200, 200, 0, "")
        slider(ll, "Position Y", "y", -200, 200, 0, "")
    }

    private fun slider(parent: LinearLayout, label: String, key: String, min: Int, max: Int, def: Int, suffix: String) {
        val tv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(0, 16, 0, 0) }
        val sb = SeekBar(this).apply { this.max = max - min; progress = prefs.getInt(key, def) - min }
        fun upd(v: Int) { tv.text = "$label  $v$suffix" }
        upd(prefs.getInt(key, def))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                upd(p + min); prefs.edit().putInt(key, p + min).apply(); refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv); parent.addView(sb)
    }

    private fun refresh() { preview.load(prefs); pushService() }

    private fun pushService() {
        val i = Intent(this, CrosshairService::class.java)
        if (prefs.getBoolean("enabled", false)) startService(i) else startService(i.setAction("STOP"))
    }
}
