package com.nexuspro.app

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

object U {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun fmt(b: Long): String {
        val gb = b / 1073741824.0
        return if (gb >= 1) String.format("%.1fGB", gb) else "${b / 1048576}MB"
    }
    fun read(path: String): String? = try { File(path).readText().trim() } catch (e: Throwable) { null }
    fun prefs(c: Context, name: String): SharedPreferences = c.getSharedPreferences(name, Context.MODE_PRIVATE)
}

/** Tambah satu baris (judul, subjudul, tag) ke dalam LinearLayout. */
fun LinearLayout.addRow(title: String, sub: String? = null, tag: String? = null, onClick: (() -> Unit)? = null): View {
    val v = LayoutInflater.from(context).inflate(R.layout.item_row, this, false)
    v.findViewById<TextView>(R.id.txtTitle).text = title
    val s = v.findViewById<TextView>(R.id.txtSub)
    if (sub == null) s.visibility = View.GONE else s.text = sub
    val t = v.findViewById<TextView>(R.id.txtTag)
    if (tag == null) t.visibility = View.GONE else t.text = tag
    if (onClick != null) v.setOnClickListener { onClick() }
    addView(v)
    return v
}

open class BaseActivity : AppCompatActivity() {
    fun setupHeader(title: String) {
        findViewById<TextView>(R.id.txtHeader).text = title
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
    }
}
