package com.nexuspro.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.android.material.materialswitch.MaterialSwitch

class AdvancedFragment : Fragment() {
    private val fields = linkedMapOf<String, EditText>()
    private lateinit var spZram: Spinner
    private lateinit var spGov: Spinner
    private lateinit var spTcp: Spinner

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_advanced, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val ctx = requireContext()
        val prefs = U.prefs(ctx, "adv")
        v.findViewById<TextView>(R.id.txtRootWarn).visibility = if (Shell.hasRoot()) View.GONE else View.VISIBLE
        v.findViewById<MaterialSwitch>(R.id.swBoot).apply {
            isChecked = prefs.getBoolean("boot", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("boot", on).apply() }
        }
        val (lvl, temp) = SysInfo.battery(ctx)
        v.findViewById<TextView>(R.id.txtBattery).text = "$lvl%  ${temp}°C"
        val (used, _) = SysInfo.ram(ctx)
        v.findViewById<TextView>(R.id.txtMemory).text = U.fmt(used)

        val ll = v.findViewById<LinearLayout>(R.id.llTune)
        fun field(label: String, key: String, path: String, def: String) {
            val row = LayoutInflater.from(ctx).inflate(R.layout.item_input, ll, false)
            row.findViewById<TextView>(R.id.txtLabel).text = label
            val e = row.findViewById<EditText>(R.id.edtValue)
            e.setText(U.read(path) ?: def)
            fields[key] = e; ll.addView(row)
        }
        field("VM Swappiness", "swap", "/proc/sys/vm/swappiness", "60")
        field("Cache Pressure", "cache", "/proc/sys/vm/vfs_cache_pressure", "100")
        field("Dirty Ratio", "dirty", "/proc/sys/vm/dirty_ratio", "20")
        field("Page Cluster", "page", "/proc/sys/vm/page-cluster", "3")
        field("Read Ahead (KB)", "ra", "/sys/block/mmcblk0/queue/read_ahead_kb", "128")

        fun spinner(label: String, items: List<String>, sel: String?): Spinner {
            ll.addView(TextView(ctx).apply { text = label; setTextAppearance(R.style.TxtTitle)
                setTextColor(resources.getColor(R.color.text_primary, null)); textSize = 14f
                setPadding(0, U.dp(ctx, 12), 0, 0) })
            val sp = Spinner(ctx)
            sp.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, items)
            sel?.let { val ix = items.indexOf(it); if (ix >= 0) sp.setSelection(ix) }
            ll.addView(sp); return sp
        }
        spZram = spinner("ZRAM", listOf("LZ4", "ZSTD", "LZO", "LZO-RLE", "Off"), "LZ4")
        val govs = U.read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
            ?.split(" ")?.filter { it.isNotBlank() } ?: listOf("schedutil", "performance", "powersave", "ondemand")
        spGov = spinner("CPU Governor", govs, U.read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"))
        val tcps = U.read("/proc/sys/net/ipv4/tcp_available_congestion_control")
            ?.split(" ")?.filter { it.isNotBlank() } ?: listOf("cubic", "reno", "bbr")
        spTcp = spinner("TCP Congestion", tcps, U.read("/proc/sys/net/ipv4/tcp_congestion_control") ?: "cubic")

        v.findViewById<Button>(R.id.btnApply).setOnClickListener {
            val script = buildScript(ctx)
            prefs.edit().putString("boot_script", script).apply()
            Thread {
                val out = Shell.run(script)
                activity?.runOnUiThread {
                    Toast.makeText(ctx, if (out.startsWith("ERR")) out else "Applied", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    private fun buildScript(ctx: android.content.Context): String {
        fun f(k: String) = fields[k]?.text.toString().trim()
        val sb = StringBuilder()
        sb.append("echo ${f("swap")} > /proc/sys/vm/swappiness\n")
        sb.append("echo ${f("cache")} > /proc/sys/vm/vfs_cache_pressure\n")
        sb.append("echo ${f("dirty")} > /proc/sys/vm/dirty_ratio\n")
        sb.append("echo ${f("page")} > /proc/sys/vm/page-cluster\n")
        sb.append("for b in /sys/block/*/queue/read_ahead_kb; do echo ${f("ra")} > \$b; done\n")
        sb.append("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo ${spGov.selectedItem} > \$c; done\n")
        sb.append("echo ${spTcp.selectedItem} > /proc/sys/net/ipv4/tcp_congestion_control\n")
        val z = spZram.selectedItem.toString()
        sb.append("swapoff /dev/block/zram0 2>/dev/null\n")
        if (z != "Off") {
            val size = SysInfo.ram(ctx).second / 2
            sb.append("echo 1 > /sys/block/zram0/reset\n")
            sb.append("echo ${z.lowercase()} > /sys/block/zram0/comp_algorithm\n")
            sb.append("echo $size > /sys/block/zram0/disksize\n")
            sb.append("mkswap /dev/block/zram0 && swapon /dev/block/zram0\n")
        }
        return sb.toString()
    }
}
