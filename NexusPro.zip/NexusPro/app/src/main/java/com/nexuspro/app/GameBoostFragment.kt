package com.nexuspro.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class GameBoostFragment : Fragment() {
    private val knownGames = listOf(
        "com.mobile.legends", "com.tencent.ig", "com.dts.freefireth", "com.dts.freefiremax",
        "com.activision.callofduty.shooter", "com.miHoYo.GenshinImpact", "com.garena.game.codm",
        "com.levelinfinite.sgameGlobal", "com.roblox.client", "com.supercell.clashofclans")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_gameboost, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val ctx = requireContext()
        val pm = ctx.packageManager
        val games = knownGames.count { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        v.findViewById<TextView>(R.id.txtGames).text = "$games games detected"

        val grid = v.findViewById<GridLayout>(R.id.grid)
        val tiles = listOf(
            Triple("📱", "Device Spoof", DeviceSpoofActivity::class.java),
            Triple("⚡", "Benchmark", BenchmarkActivity::class.java),
            Triple("🎯", "Custom Crosshair", CrosshairActivity::class.java),
            Triple("📡", "Ping Test", PingTestActivity::class.java),
            Triple("🧊", "Deep Freeze", null),
            Triple("📈", "FPS Monitor", null),
            Triple("🧹", "Debloat", null),
            Triple("🎚", "FPS Stabilizer", null),
            Triple("🗂", "Process Manager", null))
        val views = tiles.map { (icon, label, cls) ->
            val t = LayoutInflater.from(ctx).inflate(R.layout.item_tile, grid, false)
            t.findViewById<TextView>(R.id.txtIcon).text = icon
            t.findViewById<TextView>(R.id.txtLabel).text = label
            t.setOnClickListener {
                if (cls != null) startActivity(Intent(ctx, cls))
                else Toast.makeText(ctx, "$label: coming soon", Toast.LENGTH_SHORT).show()
            }
            grid.addView(t)
            label to t
        }
        v.findViewById<EditText>(R.id.edtSearch).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) {
                val q = e.toString().trim().lowercase()
                views.forEach { (l, t) -> t.visibility = if (q.isEmpty() || l.lowercase().contains(q)) View.VISIBLE else View.GONE }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }
}
