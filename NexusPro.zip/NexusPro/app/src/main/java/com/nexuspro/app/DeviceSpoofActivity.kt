package com.nexuspro.app

import android.os.Bundle
import android.widget.LinearLayout

class DeviceSpoofActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_spoof)
        setupHeader("Device Spoof")
        val ll = findViewById<LinearLayout>(R.id.llBrands)
        listOf("ASUS ROG", "RedMagic", "Samsung", "Xiaomi", "OnePlus", "iQOO").forEach {
            ll.addRow(it, tag = "SOON")
        }
    }
}
