package com.nexuspro.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket

class PingTestActivity : BaseActivity() {
    private val servers = listOf(
        "Singapore" to "dynamodb.ap-southeast-1.amazonaws.com",
        "TOKYO" to "dynamodb.ap-northeast-1.amazonaws.com",
        "Mumbai" to "dynamodb.ap-south-1.amazonaws.com",
        "Sydney" to "dynamodb.ap-southeast-2.amazonaws.com",
        "Frankfurt" to "dynamodb.eu-central-1.amazonaws.com",
        "N.Virginia" to "dynamodb.us-east-1.amazonaws.com")
    private val tags = mutableListOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ping_test)
        setupHeader("Ping Test")
        val ll = findViewById<LinearLayout>(R.id.llPing)
        servers.forEach { (n, h) -> tags.add(ll.addRow(n, h, "...").findViewById(R.id.txtTag)) }
        findViewById<Button>(R.id.btnPing).setOnClickListener { runPing() }
        runPing()
    }

    private fun runPing() {
        servers.forEachIndexed { i, (_, host) ->
            tags[i].text = "..."
            Thread {
                val res = try {
                    val t = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress(host, 443), 3000) }
                    "${(System.nanoTime() - t) / 1_000_000} ms"
                } catch (e: Exception) { "ERR" }
                runOnUiThread { tags[i].text = res }
            }.start()
        }
    }
}
