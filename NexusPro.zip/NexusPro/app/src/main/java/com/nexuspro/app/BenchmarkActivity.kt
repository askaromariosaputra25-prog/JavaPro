package com.nexuspro.app

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.materialswitch.MaterialSwitch

class BenchmarkActivity : BaseActivity() {
    private val prefs by lazy { U.prefs(this, "bench") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_benchmark)
        setupHeader("Benchmark")
        refreshBest()
        findViewById<MaterialSwitch>(R.id.swExtreme).setOnCheckedChangeListener { _, on ->
            Thread { Shell.run("for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo ${if (on) "performance" else "schedutil"} > \$c; done") }.start()
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener { run(it as Button) }
        updateThermal()
    }

    private fun refreshBest() {
        findViewById<TextView>(R.id.txtBest).text = "Best ${prefs.getInt("best", 12921)}"
    }

    private fun updateThermal() {
        val t = SysInfo.cpuTemp(this)
        findViewById<TextView>(R.id.txtTemp).text = "CPU Temp: ${"%.1f".format(t)}°C"
        val headroom = (100 - (t - 35f) * 4f).toInt().coerceIn(0, 100)
        findViewById<ProgressBar>(R.id.pbThermal).progress = headroom
        findViewById<TextView>(R.id.txtThermal).text = "$headroom%"
        findViewById<TextView>(R.id.txtLoad).text = "CPU Load: ${SysInfo.cpuLoad()}%"
    }

    private fun work(ms: Long): Long {
        val end = System.nanoTime() + ms * 1_000_000
        var n = 0L; var x = 1.000001
        while (System.nanoTime() < end) {
            for (i in 0 until 20000) x = x * 1.0000001 + Math.sqrt(i.toDouble()) % 3
            n++
        }
        return if (x == 0.0) n + 1 else n
    }

    private fun run(btn: Button) {
        btn.isEnabled = false; btn.text = "Running..."
        Thread {
            val single = work(1500) * 5
            val threads = Runtime.getRuntime().availableProcessors()
            val results = LongArray(threads)
            val ts = (0 until threads).map { i -> Thread { results[i] = work(1500) } }
            ts.forEach { it.start() }; ts.forEach { it.join() }
            val multi = results.sum() * 5
            val total = (single + multi).toInt()
            runOnUiThread {
                findViewById<TextView>(R.id.txtScore).text = "$total"
                findViewById<TextView>(R.id.txtSingle).text = "CPU Single: $single"
                findViewById<TextView>(R.id.txtMulti).text = "CPU Multi: $multi"
                prefs.edit().putInt("single", single.toInt()).apply()
                if (total > prefs.getInt("best", 12921)) prefs.edit().putInt("best", total).apply()
                refreshBest(); updateThermal()
                btn.isEnabled = true; btn.text = "Start Benchmark"
            }
        }.start()
    }
}
