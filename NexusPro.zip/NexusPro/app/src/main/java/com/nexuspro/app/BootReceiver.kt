package com.nexuspro.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Apply on Boot: jalankan script tweak terakhir (hanya root, Shizuku belum tentu aktif saat boot). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = U.prefs(ctx, "adv")
        if (!p.getBoolean("boot", false)) return
        val script = p.getString("boot_script", null) ?: return
        val pending = goAsync()
        Thread { try { Shell.su(script) } finally { pending.finish() } }.start()
    }
}
