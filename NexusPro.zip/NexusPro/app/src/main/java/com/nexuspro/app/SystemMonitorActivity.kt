package com.nexuspro.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView

class SystemMonitorActivity : BaseActivity() {
    private val h = Handler(Looper.getMainLooper())
    private var n = 0
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_system_monitor)
        setupHeader("System Monitor")
        findViewById<TextView>(R.id.txtEmmc).text =
            "eMMC  " + (U.read("/sys/block/mmcblk0/device/name") ?: "storage")
    }

    private fun update() {
        val cpu = SysInfo.cpuLoad()
        findViewById<TextView>(R.id.txtCpu).text = "$cpu%"
        findViewById<ProgressBar>(R.id.pbCpu).progress = cpu
        findViewById<TextView>(R.id.txtGpu).text = SysInfo.gpuPercent()?.let { "$it%" } ?: "No signal"
        val (ru, rt) = SysInfo.ram(this)
        val rp = (ru * 100 / rt).toInt()
        findViewById<TextView>(R.id.txtRam).text = "$rp%"
        findViewById<ProgressBar>(R.id.pbRam).progress = rp
        findViewById<TextView>(R.id.txtRamDetail).text = "${U.fmt(ru)}/${U.fmt(rt)}"
        val (su, st) = SysInfo.storage()
        val sp = (su * 100 / st).toInt()
        findViewById<TextView>(R.id.txtStorage).text = "$sp%"
        findViewById<ProgressBar>(R.id.pbStorage).progress = sp
        findViewById<TextView>(R.id.txtStorageDetail).text = "${U.fmt(su)}/${U.fmt(st)}"
        if (n++ % 5 == 0) findViewById<HistoryView>(R.id.history).add(cpu.toFloat(), rp.toFloat())
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
