package com.nexuspro.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

object SysInfo {
    /** List (freq sekarang MHz, freq max MHz) per core. */
    fun cpuCores(): List<Pair<Long, Long>> {
        val list = mutableListOf<Pair<Long, Long>>()
        var i = 0
        while (File("/sys/devices/system/cpu/cpu$i").exists()) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq"
            val cur = U.read("$base/scaling_cur_freq")?.toLongOrNull() ?: 0L
            val max = U.read("$base/cpuinfo_max_freq")?.toLongOrNull() ?: 0L
            list.add(cur / 1000 to max / 1000)
            i++
        }
        return list
    }

    /** Estimasi beban CPU dari rasio frekuensi (/proc/stat diblokir untuk app biasa). */
    fun cpuLoad(cores: List<Pair<Long, Long>> = cpuCores()): Int {
        val max = cores.sumOf { it.second }
        if (max == 0L) return 0
        return (cores.sumOf { it.first } * 100 / max).toInt().coerceIn(0, 100)
    }

    fun gpuPercent(): Int? =
        U.read("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")?.replace("%", "")?.trim()?.toIntOrNull()

    /** (used, total) bytes */
    fun ram(c: Context): Pair<Long, Long> {
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return (mi.totalMem - mi.availMem) to mi.totalMem
    }

    /** (used, total) bytes */
    fun storage(): Pair<Long, Long> {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        return (total - free) to total
    }

    /** (level %, temperature °C) */
    fun battery(c: Context): Pair<Int, Float> {
        val i: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return (level * 100 / scale) to temp
    }

    fun cpuTemp(c: Context): Float {
        val t = U.read("/sys/class/thermal/thermal_zone0/temp")?.toFloatOrNull()
        return if (t != null) (if (t > 1000) t / 1000f else t) else battery(c).second
    }
}
