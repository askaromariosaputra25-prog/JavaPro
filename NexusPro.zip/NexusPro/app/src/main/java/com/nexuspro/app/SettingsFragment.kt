package com.nexuspro.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import java.security.MessageDigest

class SettingsFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_settings, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val ctx = requireContext()
        v.findViewById<TextView>(R.id.txtName).text = "Aska Romario Saputra"
        v.findViewById<TextView>(R.id.txtEmail).text = "askaromariosaputra25@gmail.com"
        fun soon() = { Toast.makeText(ctx, "Coming soon", Toast.LENGTH_SHORT).show() }
        val dm = resources.displayMetrics

        v.findViewById<LinearLayout>(R.id.llSettings).apply {
            addRow("Language", tag = "English")
            addRow("Coin Store", onClick = soon())
            addRow("Terminal", "shizuku") { terminal(ctx) }
            addRow("Display Resolution", "${dm.widthPixels}x${dm.heightPixels} @ ${dm.densityDpi}dpi")
            addRow("Color Calibration", onClick = soon())
            addRow("Reset All Settings") {
                AlertDialog.Builder(ctx).setTitle("Reset semua pengaturan?")
                    .setPositiveButton("Reset") { _, _ ->
                        listOf("adv", "crosshair", "bench").forEach { U.prefs(ctx, it).edit().clear().apply() }
                        Toast.makeText(ctx, "Pengaturan direset", Toast.LENGTH_SHORT).show()
                    }.setNegativeButton("Batal", null).show()
            }
        }
        v.findViewById<LinearLayout>(R.id.llAbout).apply {
            addRow("App Security", tag = "Secure")
            addRow("Security Patch", Build.VERSION.SECURITY_PATCH)
            addRow("App Version", ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName)
            addRow("Min Android 9", "Target 15")
            addRow("Release Signature", signature(ctx))
        }
    }

    private fun signature(ctx: Context): String = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        val sig = pi.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
        if (sig == null) "-" else MessageDigest.getInstance("SHA-256").digest(sig)
            .joinToString(":") { "%02X".format(it) }.take(23)
    } catch (e: Throwable) { "-" }

    private fun terminal(ctx: Context) {
        val input = EditText(ctx).apply { hint = "contoh: getprop ro.product.model" }
        AlertDialog.Builder(ctx).setTitle("Terminal (Shizuku)").setView(input)
            .setPositiveButton("Run") { _, _ ->
                val cmd = input.text.toString()
                Thread {
                    val out = if (ShizukuHelper.isAvailable() && ShizukuHelper.hasPermission())
                        ShizukuHelper.exec(cmd) else "Shizuku belum aktif / izin belum diberikan"
                    activity?.runOnUiThread {
                        AlertDialog.Builder(ctx).setTitle("Output").setMessage(out.ifEmpty { "(kosong)" })
                            .setPositiveButton("OK", null).show()
                    }
                }.start()
            }.setNegativeButton("Tutup", null).show()
    }
}
