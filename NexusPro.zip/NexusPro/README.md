# NexusPro
Android native (Kotlin + XML). Package `com.nexuspro.app`.

## Catatan
Tanpa login. Opsional: taruh banner di `res/drawable-nodpi/banner.png`, ganti `@drawable/banner_anime` di `fragment_home.xml`.

## Build
Push ke GitHub -> tab Actions -> artifact `app-debug.apk`. (Gradle wrapper di-generate otomatis di workflow.)
Lokal: Android Studio -> Open -> Run.
